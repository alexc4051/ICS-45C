#include "stringclass.h"
int main()
{
	cout << "TESTING!\n\n";
	String first("foo bar");
	String second(first);
	String third;
	third = first + second;
	String fourth(third);
	fourth += first;
	String bar("bar");
	cout << "FIRST STRING:" << first << endl;
	cout << "SECOND STRING (takes first String): " << second << endl;
	cout << "Third = first + second string: " << third << endl;
	cout << "Fourth = third += first: " << fourth << endl;
	cout << "Reverse of FIRST: " << first.reverse() << endl;
	cout << "Reverse of SECOND: " << second.reverse()<< endl;
	cout << "Index of o in first and the index value of indexed: " << first.indexOf('o') << first[first.indexOf('o')] << endl;
	cout << "Index of bar in second and index value of b in bar: " << second.indexOf(bar) << second[second.indexOf(bar)] << endl;
	cout << "Size of first and second: " << first.size() << ", " << second.size() << endl;
	if (first != second)
	{cout << "first and second are not the same";
	}
	else{
		if (first == second)
		cout << "first and second are equal"<<endl;
	}
	if (first == third)
	{cout << "first and third are the same" <<endl;
	}
	else{
		if (first < third && third > second)
		cout << "first is less than third  and third is greater than second"<<endl;
	}
	
	if (first <= second && third >= second)
	cout << "first is less than or equal to second and third is greater than or equal to second" << endl;
	
	String a;
	cin >> a ;
	cout << a << endl;
	
	return 0;
}
